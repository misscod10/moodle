<?php
// ********** This file is generated DO NOT EDIT **********
$CFG->siteidentifier = 'oDG9LduXTcLAwtPCbcFlClqC0KdsOzs1localhost';
$CFG->bootstraphash = 'eee01716b2439aa2ab4d87927a764ac6';
// Only if the file is not stale and has not been defined.
if ($CFG->bootstraphash === hash_local_config_cache() && !defined('SYSCONTEXTID')) {
    define('SYSCONTEXTID', 1);
}
