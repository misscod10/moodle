<?php

class __Mustache_5867dcdcc4eafbef44a84f979e317c3e extends Mustache_Template
{
    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $buffer = '';

        $buffer .= $indent . '<div class="d-flex">
';
        $buffer .= $indent . '    <div class="bg-pulse-grey w-100" style="height: 80px"></div>
';
        $buffer .= $indent . '    <div class="mx-2 mb-2 align-self-end bg-pulse-grey" style="height: 20px; width: 20px"></div>
';
        $buffer .= $indent . '</div>';

        return $buffer;
    }
}
