<?php

class __Mustache_a45d0b2d6869bb7eb3bc09b3264896c4 extends Mustache_Template
{
    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $buffer = '';

        $buffer .= $indent . '<div class="toast-wrapper mx-auto py-0 fixed-top" role="status" aria-live="polite"></div>
';

        return $buffer;
    }
}
